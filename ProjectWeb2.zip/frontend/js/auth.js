// ================================================================
// AUTH — login, register, logout, and session restore
// ================================================================
// ══ SCREEN HELPERS ══════════════════════════════════════════════════
function showLogin(){
  document.getElementById('registerScreen').classList.add('hidden');
  document.getElementById('loginScreen').classList.remove('hidden');
}
function showRegister(){
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('registerScreen').classList.remove('hidden');
}
async function doLogin(){
  const u=document.getElementById('loginUser').value.trim();
  const p=document.getElementById('loginPass').value;
  const err=document.getElementById('loginError'); err.textContent='';
  if(!u||!p){err.textContent='กรุณากรอกชื่อผู้ใช้และรหัสผ่าน';return}
  await withBtnLock('loginSubmitBtn','กำลังเข้าสู่ระบบ…', async()=>{
    try{
      const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})});
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||'เข้าสู่ระบบไม่สำเร็จ');
      TOKEN=d.token; ME=d;
      localStorage.setItem('bms_token',TOKEN);
      localStorage.setItem('bms_me',JSON.stringify(ME));
      showApp();
    }catch(e){err.textContent=e.message}
  });
}

async function doRegister(){
  const err=document.getElementById('registerError'); err.textContent='';
  const name=document.getElementById('regName').value.trim();
  const phone=document.getElementById('regPhone').value.trim();
  const email=document.getElementById('regEmail').value.trim();
  const address=document.getElementById('regAddress').value.trim();
  const username=document.getElementById('regUser').value.trim();
  const pass=document.getElementById('regPass').value;
  const pass2=document.getElementById('regPass2').value;
  if(!name||!phone||!address||!username||!pass){err.textContent='กรุณากรอกข้อมูลให้ครบ';return}
  if(pass!==pass2){err.textContent='รหัสผ่านไม่ตรงกัน';return}
  if(pass.length<6){err.textContent='รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';return}
  await withBtnLock('registerSubmitBtn','กำลังสมัครสมาชิก…', async()=>{
    try{
      const r=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({customerName:name,phone,email,address,username,password:pass})});
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||'สมัครสมาชิกไม่สำเร็จ');
      TOKEN=d.token; ME=d;
      localStorage.setItem('bms_token',TOKEN);
      localStorage.setItem('bms_me',JSON.stringify(ME));
      showApp();
    }catch(e){err.textContent=e.message}
  });
}

document.getElementById('loginPass').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin()});
document.getElementById('loginUser').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('loginPass').focus()});

async function doLogout(){
  await fetch('/api/auth/logout',{method:'POST',headers:{Authorization:'Bearer '+TOKEN}}).catch(()=>{});
  TOKEN=''; ME=null;
  localStorage.removeItem('bms_token'); localStorage.removeItem('bms_me');
  // [FIX-11] ออกจากระบบแล้วกลับไปดูหน้าร้านต่อได้เลย ไม่ต้องบังคับเข้าหน้าล็อกอิน
  showGuestShop();
}

// ══ SHOW APP + ROLE-BASED SETUP ════════════════════════════════════

// [FIX-11] โหมดผู้เยี่ยมชม — ดูรายการหนังสือ/หยิบลงตะกร้าได้โดยไม่ต้องล็อกอิน
// จะเจอหน้าล็อกอินก็ต่อเมื่อกด "เข้าสู่ระบบ/สมัครสมาชิก" เอง หรือกด "สั่งซื้อ" ที่ต้องยืนยันตัวตนก่อนตัดสต็อก/บันทึกคำสั่งซื้อจริง
function showGuestShop(){
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('registerScreen').classList.add('hidden');
  document.getElementById('appHeader').classList.add('visible');
  document.getElementById('guestActions').style.display='';
  document.getElementById('userChip').style.display='none';
  document.getElementById('logoutBtn').style.display='none';
  document.getElementById('headerCartWrap').style.display='';
  document.getElementById('statsBar').style.display='none';
  document.getElementById('appTabs').style.display='';
  document.querySelectorAll('.tab').forEach(btn=>{
    const roles=(btn.dataset.roles||'').split(',').map(r=>r.trim());
    btn.style.display=roles.includes('guest')?'':'none';
  });
  document.querySelectorAll('.tab,.view').forEach(el=>el.classList.remove('active'));
  document.querySelector('.tab[data-view="shop"]')?.classList.add('active');
  document.getElementById('shop')?.classList.add('active');
  document.getElementById('appMain').style.display='';
  // [FIX-11] กลับมาที่ขั้นเลือกซื้อสินค้าเสมอ ไม่ให้ค้างอยู่หน้าชำระเงินจากรอบก่อน
  if (typeof backToBrowseStep === 'function') backToBrowseStep();
  loadGuestShop();
}

// Restore an existing session after every script has loaded.
if(TOKEN&&ME){
  api('/api/me').then(me=>{
    ME=me; localStorage.setItem('bms_me',JSON.stringify(ME)); showApp();
  }).catch(()=>{
    localStorage.removeItem('bms_token'); localStorage.removeItem('bms_me');
    TOKEN=''; ME=null;
    showGuestShop();
  });
} else {
  // [FIX-11] ต้องรอให้ทุกสคริปต์ (รวม shop.js ที่มี loadGuestShop) โหลด/รันเสร็จก่อน
  // ถ้าเรียก showGuestShop() ตรงนี้ทันทีจะพังเพราะ auth.js โหลดก่อน shop.js
  document.addEventListener('DOMContentLoaded', showGuestShop);
}
